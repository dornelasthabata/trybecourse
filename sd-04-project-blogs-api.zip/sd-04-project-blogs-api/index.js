const createToken = require('./createToken');
const validateToken = require('./validateToken');

module.exports = { createToken, validateToken };
