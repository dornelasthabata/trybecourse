const userController = require('./userController');
const recipeController = require('./recipeController');

module.exports = {
  userController,
  recipeController,
};
