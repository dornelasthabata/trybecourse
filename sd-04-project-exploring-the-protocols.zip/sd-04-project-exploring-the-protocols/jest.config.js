module.exports = {
  verbose: true,
  testTimeout: 30000,
};
