import React from 'react';

import ExploreHeader from '../components/ExploreHeader';

const DoneRecipes = () => (
  <div>
    <ExploreHeader title={'Receitas Feitas'} />
  </div>
);

export default DoneRecipes;
