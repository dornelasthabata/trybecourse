export const SEARCH_RESULT_MORE_ONE = 'SEARCH_RESULT_MORE_ONE';

export const searchResultMoreOne = () => ({
  type: SEARCH_RESULT_MORE_ONE,
});
