const japaneseMeals = {
  'meals': [
    {
      'strMeal': 'Chicken Karaage',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/tyywsw1505930373.jpg',
      'idMeal': '52831'
    },
    {
      'strMeal': 'Honey Teriyaki Salmon',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/xxyupu1468262513.jpg',
      'idMeal': '52773'
    },
    {
      'strMeal': 'Katsu Chicken curry',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/vwrpps1503068729.jpg',
      'idMeal': '52820'
    },
    {
      'strMeal': 'Teriyaki Chicken Casserole',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/wvpsxx1468256321.jpg',
      'idMeal': '52772'
    },
    {
      'strMeal': 'Yaki Udon',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/wrustq1511475474.jpg',
      'idMeal': '52871'
    }
  ],
};

module.exports = japaneseMeals;
