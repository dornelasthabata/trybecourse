const challengeResult13 = [
  { 'Produto': 'Pâté chinois', 'Preço': 24 },
  { 'Produto': 'Sirop d\'érable', 'Preço': 28.5 },
  { 'Produto': 'Steeleye Stout', 'Preço': 18 }
];

module.exports = challengeResult13;
