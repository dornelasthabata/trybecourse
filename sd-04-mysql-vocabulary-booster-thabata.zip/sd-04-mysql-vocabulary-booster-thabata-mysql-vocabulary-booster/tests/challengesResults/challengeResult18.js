const challengeResult18 = [
  { total: 14 }
];

module.exports = challengeResult18;
