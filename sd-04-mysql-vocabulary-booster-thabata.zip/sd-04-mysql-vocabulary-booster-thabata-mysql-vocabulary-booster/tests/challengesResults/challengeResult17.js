const challengeResult17 = [
  {
    'Nome completo': 'Den Raphaely',
    'Data de início': '24/03/1998',
    'Data de rescisão': '31/12/1999',
    'Anos trabalhados': '1.77'
  },
  {
    'Nome completo': 'Jennifer Whalen',
    'Data de início': '01/07/1994',
    'Data de rescisão': '31/12/1998',
    'Anos trabalhados': '4.50'
  },
  {
    'Nome completo': 'Jennifer Whalen',
    'Data de início': '17/09/1987',
    'Data de rescisão': '17/06/1993',
    'Anos trabalhados': '5.75'
  },
  {
    'Nome completo': 'Jonathon Taylor',
    'Data de início': '24/03/1998',
    'Data de rescisão': '31/12/1998',
    'Anos trabalhados': '0.77'
  },
  {
    'Nome completo': 'Jonathon Taylor',
    'Data de início': '01/01/1999',
    'Data de rescisão': '31/12/1999',
    'Anos trabalhados': '1.00'
  },
  {
    'Nome completo': 'Lex De Haan',
    'Data de início': '13/01/1993',
    'Data de rescisão': '24/07/1998',
    'Anos trabalhados': '5.53'
  },
  {
    'Nome completo': 'Michael Hartstein',
    'Data de início': '17/02/1996',
    'Data de rescisão': '19/12/1999',
    'Anos trabalhados': '3.84'
  },
  {
    'Nome completo': 'Neena Kochhar',
    'Data de início': '28/10/1993',
    'Data de rescisão': '15/03/1997',
    'Anos trabalhados': '3.38'
  },
  {
    'Nome completo': 'Neena Kochhar',
    'Data de início': '21/09/1989',
    'Data de rescisão': '27/10/1993',
    'Anos trabalhados': '4.10'
  },
  {
    'Nome completo': 'Payam Kaufling',
    'Data de início': '01/01/1999',
    'Data de rescisão': '31/12/1999',
    'Anos trabalhados': '1.00'
  }
];

module.exports = challengeResult17;
