const challengeResult4 = [
  {
    'Cargo': 'Purchasing Clerk',
    'Média salarial': '2780.00',
    'Senioridade': 'Júnior'
  },
  {
    'Cargo': 'Stock Clerk',
    'Média salarial': '2785.00',
    'Senioridade': 'Júnior'
  },
  {
    'Cargo': 'Shipping Clerk',
    'Média salarial': '3215.00',
    'Senioridade': 'Júnior'
  },
  {
    'Cargo': 'Administration Assistant',
    'Média salarial': '4400.00',
    'Senioridade': 'Júnior'
  },
  {
    'Cargo': 'Programmer',
    'Média salarial': '5760.00',
    'Senioridade': 'Júnior'
  },
  {
    'Cargo': 'Marketing Representative',
    'Média salarial': '6000.00',
    'Senioridade': 'Pleno'
  },
  {
    'Cargo': 'Human Resources Representative',
    'Média salarial': '6500.00',
    'Senioridade': 'Pleno'
  },
  {
    'Cargo': 'Stock Manager',
    'Média salarial': '7280.00',
    'Senioridade': 'Pleno'
  },
  {
    'Cargo': 'Accountant',
    'Média salarial': '7920.00',
    'Senioridade': 'Sênior'
  },
  {
    'Cargo': 'Public Accountant',
    'Média salarial': '8300.00',
    'Senioridade': 'Sênior'
  },
  {
    'Cargo': 'Sales Representative',
    'Média salarial': '8350.00',
    'Senioridade': 'Sênior'
  },
  {
    'Cargo': 'Public Relations Representative',
    'Média salarial': '10000.00',
    'Senioridade': 'Sênior'
  },
  {
    'Cargo': 'Purchasing Manager',
    'Média salarial': '11000.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'Accounting Manager',
    'Média salarial': '12000.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'Finance Manager',
    'Média salarial': '12000.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'Sales Manager',
    'Média salarial': '12200.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'Marketing Manager',
    'Média salarial': '13000.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'Administration Vice President',
    'Média salarial': '17000.00',
    'Senioridade': 'CEO'
  },
  {
    'Cargo': 'President',
    'Média salarial': '24000.00',
    'Senioridade': 'CEO'
  }
];

module.exports = challengeResult4;
