const challengeResult14 = [
  { 'País': 'Argentina' },
  { 'País': 'Australia' },
  { 'País': 'Austria' },
  { 'País': 'Belgium' },
  { 'País': 'Brazil' }
];

module.exports = challengeResult14;
