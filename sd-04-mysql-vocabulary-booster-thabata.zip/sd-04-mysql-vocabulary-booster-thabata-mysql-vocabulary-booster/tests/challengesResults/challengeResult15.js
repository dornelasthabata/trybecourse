const challengeResult15 = [
  { 'Média salarial': '5760.00' }
];

module.exports = challengeResult15;
