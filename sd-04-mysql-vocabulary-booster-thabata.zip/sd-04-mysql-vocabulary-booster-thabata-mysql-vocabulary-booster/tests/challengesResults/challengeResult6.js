const challengeResult6 = [
  {
    'Nome completo': 'Payam Kaufling',
    'Cargo': 'Stock Clerk',
    'Data de início do cargo': '1999-01-01',
    'Departamento': 'Shipping'
  },
  {
    'Nome completo': 'Neena Kochhar',
    'Cargo': 'Accounting Manager',
    'Data de início do cargo': '1993-10-28',
    'Departamento': 'Accounting'
  },
  {
    'Nome completo': 'Neena Kochhar',
    'Cargo': 'Public Accountant',
    'Data de início do cargo': '1989-09-21',
    'Departamento': 'Accounting'
  },
  {
    'Nome completo': 'Michael Hartstein',
    'Cargo': 'Marketing Representative',
    'Data de início do cargo': '1996-02-17',
    'Departamento': 'Marketing'
  },
  {
    'Nome completo': 'Lex De Haan',
    'Cargo': 'Programmer',
    'Data de início do cargo': '1993-01-13',
    'Departamento': 'IT'
  },
  {
    'Nome completo': 'Jonathon Taylor',
    'Cargo': 'Sales Manager',
    'Data de início do cargo': '1999-01-01',
    'Departamento': 'Sales'
  },
  {
    'Nome completo': 'Jonathon Taylor',
    'Cargo': 'Sales Representative',
    'Data de início do cargo': '1998-03-24',
    'Departamento': 'Sales'
  },
  {
    'Nome completo': 'Jennifer Whalen',
    'Cargo': 'Administration Assistant',
    'Data de início do cargo': '1987-09-17',
    'Departamento': 'Executive'
  },
  {
    'Nome completo': 'Jennifer Whalen',
    'Cargo': 'Public Accountant',
    'Data de início do cargo': '1994-07-01',
    'Departamento': 'Executive'
  },
  {
    'Nome completo': 'Den Raphaely',
    'Cargo': 'Stock Clerk',
    'Data de início do cargo': '1998-03-24',
    'Departamento': 'Shipping'
  }
];

module.exports = challengeResult6;
