const challengeResult3 = [
  {
    'Cargo': 'Administration Assistant',
    'Diferença entre salários máximo e mínimo': '3000'
  },
  {
    'Cargo': 'Purchasing Clerk',
    'Diferença entre salários máximo e mínimo': '3000'
  },
  {
    'Cargo': 'Shipping Clerk',
    'Diferença entre salários máximo e mínimo': '3000'
  },
  {
    'Cargo': 'Stock Clerk',
    'Diferença entre salários máximo e mínimo': '3000'
  },
  {
    'Cargo': 'Stock Manager',
    'Diferença entre salários máximo e mínimo': '3000'
  },
  {
    'Cargo': 'Accountant',
    'Diferença entre salários máximo e mínimo': '4800'
  },
  {
    'Cargo': 'Public Accountant',
    'Diferença entre salários máximo e mínimo': '4800'
  },
  {
    'Cargo': 'Human Resources Representative',
    'Diferença entre salários máximo e mínimo': '5000'
  },
  {
    'Cargo': 'Marketing Representative',
    'Diferença entre salários máximo e mínimo': '5000'
  },
  {
    'Cargo': 'Marketing Manager',
    'Diferença entre salários máximo e mínimo': '6000'
  },
  {
    'Cargo': 'Programmer',
    'Diferença entre salários máximo e mínimo': '6000'
  },
  {
    'Cargo': 'Public Relations Representative',
    'Diferença entre salários máximo e mínimo': '6000'
  },
  {
    'Cargo': 'Sales Representative',
    'Diferença entre salários máximo e mínimo': '6000'
  },
  {
    'Cargo': 'Purchasing Manager',
    'Diferença entre salários máximo e mínimo': '7000'
  },
  {
    'Cargo': 'Accounting Manager',
    'Diferença entre salários máximo e mínimo': '7800'
  },
  {
    'Cargo': 'Finance Manager',
    'Diferença entre salários máximo e mínimo': '7800'
  },
  {
    'Cargo': 'Sales Manager',
    'Diferença entre salários máximo e mínimo': '10000'
  },
  {
    'Cargo': 'Administration Vice President',
    'Diferença entre salários máximo e mínimo': '15000'
  },
  {
    'Cargo': 'President',
    'Diferença entre salários máximo e mínimo': '20000'
  }
];

module.exports = challengeResult3;
