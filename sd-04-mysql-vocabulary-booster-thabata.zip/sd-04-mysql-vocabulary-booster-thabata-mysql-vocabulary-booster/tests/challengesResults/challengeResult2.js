const challengeResult2 = [
  { 'Cargo': 'Accountant', 'Nível': 'Baixo' },
  { 'Cargo': 'Accounting Manager', 'Nível': 'Médio' },
  { 'Cargo': 'Administration Assistant', 'Nível': 'Baixo' },
  { 'Cargo': 'Administration Vice President', 'Nível': 'Alto' },
  { 'Cargo': 'Finance Manager', 'Nível': 'Médio' },
  { 'Cargo': 'Human Resources Representative', 'Nível': 'Baixo' },
  { 'Cargo': 'Marketing Manager', 'Nível': 'Médio' },
  { 'Cargo': 'Marketing Representative', 'Nível': 'Baixo' },
  { 'Cargo': 'President', 'Nível': 'Altíssimo' },
  { 'Cargo': 'Programmer', 'Nível': 'Baixo' },
  { 'Cargo': 'Public Accountant', 'Nível': 'Baixo' },
  { 'Cargo': 'Public Relations Representative', 'Nível': 'Médio' },
  { 'Cargo': 'Purchasing Clerk', 'Nível': 'Baixo' },
  { 'Cargo': 'Purchasing Manager', 'Nível': 'Médio' },
  { 'Cargo': 'Sales Manager', 'Nível': 'Médio' },
  { 'Cargo': 'Sales Representative', 'Nível': 'Médio' },
  { 'Cargo': 'Shipping Clerk', 'Nível': 'Baixo' },
  { 'Cargo': 'Stock Clerk', 'Nível': 'Baixo' },
  { 'Cargo': 'Stock Manager', 'Nível': 'Baixo' },
];

module.exports = challengeResult2;
