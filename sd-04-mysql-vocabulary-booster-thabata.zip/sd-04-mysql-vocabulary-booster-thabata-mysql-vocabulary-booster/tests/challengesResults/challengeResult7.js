const challengeResult7 = [
  {
    'Nome completo': 'DEN RAPHAELY',
    'Data de início': '1998-03-24',
    'Salário': '11000.00'
  },
  {
    'Nome completo': 'JONATHON TAYLOR',
    'Data de início': '1998-03-24',
    'Salário': '8600.00'
  },
  {
    'Nome completo': 'JONATHON TAYLOR',
    'Data de início': '1999-01-01',
    'Salário': '8600.00'
  },
  {
    'Nome completo': 'LEX DE HAAN',
    'Data de início': '1993-01-13',
    'Salário': '17000.00'
  },
  {
    'Nome completo': 'MICHAEL HARTSTEIN',
    'Data de início': '1996-02-17',
    'Salário': '13000.00'
  },
  {
    'Nome completo': 'PAYAM KAUFLING',
    'Data de início': '1999-01-01',
    'Salário': '7900.00'
  }
];

module.exports = challengeResult7;
