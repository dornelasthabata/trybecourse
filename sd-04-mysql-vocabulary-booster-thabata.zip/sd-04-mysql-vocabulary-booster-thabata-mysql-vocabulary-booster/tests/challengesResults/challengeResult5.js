const challengeResult5 = [
  {
    'Cargo': 'Administration Assistant',
    'Variação Salarial': '3000',
    'Média mínima mensal': '250.00',
    'Média máxima mensal': '500.00'
  },
  {
    'Cargo': 'Purchasing Clerk',
    'Variação Salarial': '3000',
    'Média mínima mensal': '208.33',
    'Média máxima mensal': '458.33'
  },
  {
    'Cargo': 'Shipping Clerk',
    'Variação Salarial': '3000',
    'Média mínima mensal': '208.33',
    'Média máxima mensal': '458.33'
  },
  {
    'Cargo': 'Stock Clerk',
    'Variação Salarial': '3000',
    'Média mínima mensal': '166.67',
    'Média máxima mensal': '416.67'
  },
  {
    'Cargo': 'Stock Manager',
    'Variação Salarial': '3000',
    'Média mínima mensal': '458.33',
    'Média máxima mensal': '708.33'
  },
  {
    'Cargo': 'Accountant',
    'Variação Salarial': '4800',
    'Média mínima mensal': '350.00',
    'Média máxima mensal': '750.00'
  },
  {
    'Cargo': 'Public Accountant',
    'Variação Salarial': '4800',
    'Média mínima mensal': '350.00',
    'Média máxima mensal': '750.00'
  },
  {
    'Cargo': 'Human Resources Representative',
    'Variação Salarial': '5000',
    'Média mínima mensal': '333.33',
    'Média máxima mensal': '750.00'
  },
  {
    'Cargo': 'Marketing Representative',
    'Variação Salarial': '5000',
    'Média mínima mensal': '333.33',
    'Média máxima mensal': '750.00'
  },
  {
    'Cargo': 'Marketing Manager',
    'Variação Salarial': '6000',
    'Média mínima mensal': '750.00',
    'Média máxima mensal': '1250.00'
  },
  {
    'Cargo': 'Programmer',
    'Variação Salarial': '6000',
    'Média mínima mensal': '333.33',
    'Média máxima mensal': '833.33'
  },
  {
    'Cargo': 'Public Relations Representative',
    'Variação Salarial': '6000',
    'Média mínima mensal': '375.00',
    'Média máxima mensal': '875.00'
  },
  {
    'Cargo': 'Sales Representative',
    'Variação Salarial': '6000',
    'Média mínima mensal': '500.00',
    'Média máxima mensal': '1000.00'
  },
  {
    'Cargo': 'Purchasing Manager',
    'Variação Salarial': '7000',
    'Média mínima mensal': '666.67',
    'Média máxima mensal': '1250.00'
  },
  {
    'Cargo': 'Accounting Manager',
    'Variação Salarial': '7800',
    'Média mínima mensal': '683.33',
    'Média máxima mensal': '1333.33'
  },
  {
    'Cargo': 'Finance Manager',
    'Variação Salarial': '7800',
    'Média mínima mensal': '683.33',
    'Média máxima mensal': '1333.33'
  },
  {
    'Cargo': 'Sales Manager',
    'Variação Salarial': '10000',
    'Média mínima mensal': '833.33',
    'Média máxima mensal': '1666.67'
  },
  {
    'Cargo': 'Administration Vice President',
    'Variação Salarial': '15000',
    'Média mínima mensal': '1250.00',
    'Média máxima mensal': '2500.00'
  },
  {
    'Cargo': 'President',
    'Variação Salarial': '20000',
    'Média mínima mensal': '1666.67',
    'Média máxima mensal': '3333.33'
  }
];

module.exports = challengeResult5;
