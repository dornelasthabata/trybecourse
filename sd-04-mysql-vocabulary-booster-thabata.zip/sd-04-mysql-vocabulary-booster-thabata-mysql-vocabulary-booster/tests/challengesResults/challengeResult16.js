const challengeResult16 = [
  { total_empregos: 2 }
];

module.exports = challengeResult16;
