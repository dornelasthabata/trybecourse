const challengeResult11 = [
  {
    'Nome': "Alejandra Camino",
    'País': "Spain",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Alexander Feuer",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Ana Trujillo",
    'País': "Mexico",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Anabela Domingues",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "André Fonseca",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Ann Devon",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Annette Roulet",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Antonio Moreno",
    'País': "Mexico",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Aria Cruz",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Art Braunschweiger",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Bernardo Batista",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Carine Schmitt",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Carlos González",
    'País': "Venezuela",
    'Número de compatriotas': 3
  },
  {
    'Nome': "Carlos Hernández",
    'País': "Venezuela",
    'Número de compatriotas': 3
  },
  {
    'Nome': "Catherine Dewey",
    'País': "Belgium",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Christina Berglund",
    'País': "Sweden",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Daniel Tonini",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Diego Roel",
    'País': "Spain",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Dominique Perrier",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Eduardo Saavedra",
    'País': "Spain",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Elizabeth Brown",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Elizabeth Lincoln",
    'País': "Canada",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Felipe Izquierdo",
    'País': "Venezuela",
    'Número de compatriotas': 3
  },
  {
    'Nome': "Fran Wilson",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Francisco Chang",
    'País': "Mexico",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Frédérique Citeaux",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Georg Pipps",
    'País': "Austria",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Giovanni Rovelli",
    'País': "Italy",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Guillermo Fernández",
    'País': "Mexico",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Hanna Moos",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Hari Kumar",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Helen Bennett",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Helvetius Nagy",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Henriette Pfalzheim",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Horst Kloss",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Howard Snyder",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Isabel de Castro",
    'País': "Portugal",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Jaime Yorres",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Janete Limeira",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Janine Labrune",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Jean Fresnière",
    'País': "Canada",
    'Número de compatriotas': 2
  },
  {
    'Nome': "John Steel",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Jose Pavarotti",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "José Pedro Freyre",
    'País': "Spain",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Jytte Petersen",
    'País': "Denmark",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Karin Josephs",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Karl Jablonski",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Laurence Lebihans",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Lino Rodriguez",
    'País': "Portugal",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Liu Wong",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Liz Nixon",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Lúcia Carvalho",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Manuel Pereira",
    'País': "Venezuela",
    'Número de compatriotas': 3
  },
  {
    'Nome': "Maria Anders",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Maria Larsson",
    'País': "Sweden",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Marie Bertrand",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Mario Pontes",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Martín Sommer",
    'País': "Spain",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Martine Rancé",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Mary Saveley",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Matti Karttunen",
    'País': "Finland",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Maurizio Moroni",
    'País': "Italy",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Michael Holz",
    'País': "Switzerland",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Miguel Angel Paolino",
    'País': "Mexico",
    'Número de compatriotas': 4
  },
  {
    'Nome': "Palle Ibsen",
    'País': "Denmark",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Paolo Accorti",
    'País': "Italy",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Pascale Cartrain",
    'País': "Belgium",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Patricio Simpson",
    'País': "Argentina",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Paul Henriot",
    'País': "France",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Paula Parente",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Paula Wilson",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Pedro Afonso",
    'País': "Brazil",
    'Número de compatriotas': 8
  },
  {
    'Nome': "Peter Franken",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Philip Cramer",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Pirkko Koskitalo",
    'País': "Finland",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Renate Messner",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Rene Phillips",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Rita Müller",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Roland Mendel",
    'País': "Austria",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Sergio Gutiérrez",
    'País': "Argentina",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Simon Crowther",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Sven Ottlieb",
    'País': "Germany",
    'Número de compatriotas': 10
  },
  {
    'Nome': "Thomas Hardy",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Victoria Ashworth",
    'País': "UK",
    'Número de compatriotas': 6
  },
  {
    'Nome': "Yang Wang",
    'País': "Switzerland",
    'Número de compatriotas': 1
  },
  {
    'Nome': "Yoshi Latimer",
    'País': "USA",
    'Número de compatriotas': 12
  },
  {
    'Nome': "Yoshi Tannamuri",
    'País': "Canada",
    'Número de compatriotas': 2
  },
  {
    'Nome': "Yvonne Moncada",
    'País': "Argentina",
    'Número de compatriotas': 2
  }
];

module.exports = challengeResult11;
