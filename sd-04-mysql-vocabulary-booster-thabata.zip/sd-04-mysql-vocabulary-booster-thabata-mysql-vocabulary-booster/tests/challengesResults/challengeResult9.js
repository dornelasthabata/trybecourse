const challengeResult9 = [
  {
    'Nome completo': 'Anne Dodsworth',
    'Total de pedidos': 6
  },
  {
    'Nome completo': 'Steven Buchanan',
    'Total de pedidos': 11
  },
  {
    'Nome completo': 'Robert King',
    'Total de pedidos': 14
  },
  {
    'Nome completo': 'Michael Suyama',
    'Total de pedidos': 18
  },
  {
    'Nome completo': 'Andrew Fuller',
    'Total de pedidos': 20
  },
  {
    'Nome completo': 'Laura Callahan',
    'Total de pedidos': 27
  },
  {
    'Nome completo': 'Nancy Davolio',
    'Total de pedidos': 29
  },
  {
    'Nome completo': 'Janet Leverling',
    'Total de pedidos': 31
  },
  {
    'Nome completo': 'Margaret Peacock',
    'Total de pedidos': 40
  }
];

module.exports = challengeResult9;
