const challengeResult19 = [
  {
    'Nome completo': 'Neena Kochhar',
    'Departamento': 'Accounting',
    'Cargo': 'Accounting Manager'
  },
  {
    'Nome completo': 'Neena Kochhar',
    'Departamento': 'Accounting',
    'Cargo': 'Public Accountant'
  }
];

module.exports = challengeResult19;
