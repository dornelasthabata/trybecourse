SELECT HOUR(submitted_date) AS submitted_hour FROM northwind.purchase_orders;
