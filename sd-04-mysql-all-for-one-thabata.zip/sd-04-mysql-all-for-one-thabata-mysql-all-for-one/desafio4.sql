SELECT COUNT(product_name) FROM northwind.products;
