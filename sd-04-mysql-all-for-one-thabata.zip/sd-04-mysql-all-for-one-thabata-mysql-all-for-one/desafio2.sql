SELECT * FROM northwind.products;
