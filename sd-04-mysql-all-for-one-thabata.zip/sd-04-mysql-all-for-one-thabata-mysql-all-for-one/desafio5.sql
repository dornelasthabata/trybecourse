SELECT * FROM northwind.products LIMIT 10 OFFSET 3;
