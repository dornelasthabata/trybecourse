SELECT id FROM northwind.products;
