SELECT id FROM northwind.products ORDER BY id DESC LIMIT 5;
