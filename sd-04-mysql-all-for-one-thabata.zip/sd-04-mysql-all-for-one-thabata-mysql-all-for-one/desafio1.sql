-- Exiba apenas os nomes dos produtos na tabela products.
SELECT product_name FROM northwind.products;
