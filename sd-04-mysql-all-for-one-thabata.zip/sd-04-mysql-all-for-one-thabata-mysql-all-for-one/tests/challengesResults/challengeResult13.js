const challengeResult13 = [
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 3 }
];

module.exports = challengeResult13;
