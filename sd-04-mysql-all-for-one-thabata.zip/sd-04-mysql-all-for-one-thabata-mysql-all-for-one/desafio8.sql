SELECT 5 + 6 AS 'A', 'de' AS 'Trybe', 2 + 8 AS 'eh';
