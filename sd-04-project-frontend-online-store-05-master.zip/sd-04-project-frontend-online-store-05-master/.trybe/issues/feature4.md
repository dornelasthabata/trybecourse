Criar a listagem de produtos. Fazer a exibição resumida do produto (o "card" que aparece na listagem). A exibição deve ter título, foto e preço. Fazer requisição à API do Mercado Livre enviando os termos buscados por quem usa e usar o retorno para fazer a listagem dos produtos. Se a busca não retornar resultados, gerar a tela correspondente com o texto "Nenhum produto foi encontrado".

- [Card 05.1](https://github.com/my-org/my-repo/tree/master/wireframes/card_05.1.png)
- [Card 05.2](https://github.com/my-org/my-repo/tree/master/wireframes/card_05.2.png)
