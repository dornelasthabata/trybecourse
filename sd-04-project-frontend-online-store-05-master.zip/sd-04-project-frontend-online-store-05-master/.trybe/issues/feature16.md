Criar um seletor dropdown que permite a lista de produtos ser ordenada por maior e menor preço.

- [Ordenação](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_ordering.png)
