Como usuário, eu quero clicar no card do produto e visualizar a exibição detalhada do produto com nome do produto, imagem, preço e especificação técnica. A tela também deve possuir um botão que leve ao carrinho de compras.

- [Card 07](https://github.com/my-org/my-repo/tree/master/wireframes/card_07.png)
