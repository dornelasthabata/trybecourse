Adicionar aos produtos da listagem de produtos, em sua exibição resumida, um botão para adicioná-los ao carrinho.

- [Card 08](https://github.com/my-org/my-repo/tree/master/wireframes/card_08.png)
