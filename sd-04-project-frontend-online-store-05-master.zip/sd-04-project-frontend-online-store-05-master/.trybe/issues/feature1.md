Criar o campo de busca da tela principal, a listagem de produtos, inicialmente vazia. A listagem vazia deve conter a mensagem "Digite algum termo de pesquisa ou escolha uma categoria.".

- [Card 02](https://github.com/my-org/my-repo/tree/master/wireframes/card_02.png)
