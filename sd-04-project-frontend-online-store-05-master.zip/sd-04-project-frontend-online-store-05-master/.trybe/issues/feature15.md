Faça um layout completo responsivo, para telas pequenas.
