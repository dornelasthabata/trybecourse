Coloque uma animação no carrinho quando adicionar/remover um produto
