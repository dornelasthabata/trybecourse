Criar o botão de carrinho de compras na tela principal, de listagem de produtos, e criar uma tela para o carrinho de compras, inicialmente vazio.

- [Card 03](https://github.com/my-org/my-repo/tree/master/wireframes/card_03.png)
- [Botão de carrinho de compras](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_shopping_cart_button.png)
