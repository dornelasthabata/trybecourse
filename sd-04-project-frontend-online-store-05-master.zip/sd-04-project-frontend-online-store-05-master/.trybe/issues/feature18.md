Exibir o conteúdo do carrinho num slider na lateral da tela, de forma que ele possa ser exibido e escondido através da interação com botão.

- [Slider 1](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_slider.1.png)
- [Slider 2](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_slider.1.png)
