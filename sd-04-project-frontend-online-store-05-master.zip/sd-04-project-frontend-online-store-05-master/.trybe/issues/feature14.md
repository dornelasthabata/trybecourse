Adicionar indicador de frete grátis à exibição resumida e detalhada do produto.

- [Card 15.1](https://github.com/my-org/my-repo/tree/master/wireframes/card_15.1.png)
- [Card 15.2](https://github.com/my-org/my-repo/tree/master/wireframes/card_15.2.png)
