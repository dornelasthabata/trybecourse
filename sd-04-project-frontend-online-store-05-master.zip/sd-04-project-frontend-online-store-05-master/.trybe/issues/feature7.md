Adicionar formulário ao produto, em sua exibição detalhada, para permitir adicionar avaliações com nota de 1 a 5 estrelas e comentários (o comentário deve ser opcional, sendo possível enviar apenas a nota). Exibir a lista de avaliações já feitas. Se quem usa sai e volta da tela, a nota e as avaliações não devem ser apagadas.

- [Card 11.1](https://github.com/my-org/my-repo/tree/master/wireframes/card_11.1.png)
- [Card 11.2](https://github.com/my-org/my-repo/tree/master/wireframes/card_11.2.png)
