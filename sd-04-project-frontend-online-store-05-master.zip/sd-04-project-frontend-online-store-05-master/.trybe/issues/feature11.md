Adicionar ao ícone do carrinho, em todas as telas em que ele aparece, um número com a quantidade de produtos adicionados

- [Card 13](https://github.com/my-org/my-repo/tree/master/wireframes/card_13.png)
