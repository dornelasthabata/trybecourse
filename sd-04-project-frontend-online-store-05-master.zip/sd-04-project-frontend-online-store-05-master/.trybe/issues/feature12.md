Adicionar ao site um layout agradável para quem usa ter uma boa experiência
