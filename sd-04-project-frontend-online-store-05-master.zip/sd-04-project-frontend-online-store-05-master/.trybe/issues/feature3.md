Listar filtros de categoria obtidos da API na tela principal, de listagem do produto. A requisição da API para recuperar as categorias deve ser feita uma única vez após o carregamento da tela.

- [Card 04](https://github.com/my-org/my-repo/tree/master/wireframes/card_04.png)
