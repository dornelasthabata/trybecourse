Destacar produtos que já foram adicionados ao carrinho, diferenciando-o dos demais produtos da lista da página principal

- [Marcação do produto](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_marked_product.png)
