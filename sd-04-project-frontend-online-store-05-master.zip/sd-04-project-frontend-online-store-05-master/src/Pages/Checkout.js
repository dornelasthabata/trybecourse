import React, { Component } from 'react';
import CreateForm from '../components/CreateForm';

class Checkout extends Component {
  render() {
    return (
      <div>
        <CreateForm />
      </div>
    );
  }
}

export default Checkout;
